package com.rays.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rays.dao.DaoImpl;
import com.rays.model.Customer;
import com.rays.service.Service;


/**
 * Servlet implementation class CRegistration
 */
@WebServlet("/CRegistration")
public class CRegistration extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CRegistration() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session=request.getSession();
		
		String user_name=request.getParameter("user_name");
		String address=request.getParameter("address");
		String email=request.getParameter("email");
		String phone=request.getParameter("phone");
		String password=request.getParameter("password");		
		Customer customer=new Customer(user_name, address, email, phone, password);
		try{
			
			
			Service service = new Service();
			DaoImpl daoImpl = new DaoImpl();
			service.setUserDao(daoImpl);
			service.addUser(customer);	
			session.setAttribute("reg", "reg");
			
			request.getRequestDispatcher("login.jsp").forward(request, response);
			
		} catch(Exception exception) {
			System.out.println("Error in CReg : "+exception);
		}
		
	}
	

}
