package com.rays.model;



public class Admin {
		
	private String mail;		
	private String aname;		
	private String password;
			
	public Admin() {
		
	}

	public Admin(String mail, String aname, String password) {
		super();
		this.mail = mail;
		this.aname = aname;
		this.password = password;		
	}

	
	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getAname() {
		return aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	

	@Override
	public String toString() {
		return "Admin [mail=" + mail + ", aname=" + aname + ", password=" + password + "]";
	}
	
	
}
