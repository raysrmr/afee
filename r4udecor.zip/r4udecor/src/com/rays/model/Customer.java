package com.rays.model;


public class Customer {
		
	private String user_name;	
	private String address;	
	private String phone;		
	private String mail;			
	private String password;
	
	public Customer() {
		
	}

	public Customer(String user_name, String address, String mail, String phone, String password) {
		super();
		this.address = address;
		this.phone = phone;
		this.mail = mail;
		this.user_name = user_name;
		this.password = password;
	}

	

	public String getUser_name() {
		return user_name;
	}

	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}	

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	@Override
	public String toString() {
		return "Customer [user_name=" + user_name + ", address=" + address + ", phone=" + phone + ", mail=" + mail + ", password=" + password + "]";
	}
	
	
}
