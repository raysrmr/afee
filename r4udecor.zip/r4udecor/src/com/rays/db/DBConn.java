package com.rays.db;

import java.sql.Connection;
import java.sql.DriverManager;

import com.mysql.jdbc.Driver;

public class DBConn {
	
	public static Connection getCon()
	{
		Connection con=null;
		try {
			Driver d=new com.mysql.jdbc.Driver();
			DriverManager.registerDriver(d);
			//con=DriverManager.getConnection("jdbc:mysql://localhost:3306/r4u", "root", "raysrmr");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/bnlivein_lict_pu", "bnlivein_lict", "java@1234");
		}catch (Exception e) {
			// TODO: handle exception
		}
		return con;
	}

}
