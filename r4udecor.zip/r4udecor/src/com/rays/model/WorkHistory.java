package com.rays.model;

import java.sql.Blob;

public class WorkHistory {
	
	private int work_id;
	private String category;
	private Blob image;
	private Blob video;
	
	
	public WorkHistory() {
		
	}


	public WorkHistory(String category, Blob image, Blob video) {
		super();
		this.category = category;
		this.image = image;
		this.video = video;
	}

	
	public int getWork_id() {
		return work_id;
	}


	public void setWork_id(int work_id) {
		this.work_id = work_id;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public Blob getImage() {
		return image;
	}


	public void setImage(Blob image) {
		this.image = image;
	}


	public Blob getVideo() {
		return video;
	}


	public void setVideo(Blob video) {
		this.video = video;
	}


	@Override
	public String toString() {
		return "WorkHistory [id=" + work_id + ", category=" + category + ", image=" + image + ", video=" + video + "]";
	}


	
	
	
}
