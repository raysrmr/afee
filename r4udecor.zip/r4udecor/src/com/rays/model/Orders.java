package com.rays.model;

import java.sql.Blob;




public class Orders {
	
	private int order_id;
	private String client_id;	
	private String productId;
	private String size;
	private int quantity;		
	private Blob image;		
	private double totamount;
		
	public Orders() {
		
	}
	
	public Orders(int order_id, String client_id, String productId, int quantity, String size, Blob image, double totamount) {
		super();
		this.order_id=order_id;
		this.client_id = client_id;
		this.productId = productId;
		this.quantity = quantity;
		this.size = size;
		this.image = image;
		this.totamount=totamount;
	}
	public Orders( String client_id, String productId, int quantity, String size, Blob image, double totamount) {
		super();		
		this.client_id = client_id;
		this.productId = productId;
		this.quantity = quantity;
		this.size = size;
		this.image = image;
		this.totamount=totamount;
	}
	public Orders(int order_id, String client_id, String productId, int quantity, String size, double totamount) {
		super();
		this.order_id=order_id;
		this.client_id = client_id;
		this.productId = productId;
		this.quantity = quantity;
		this.size = size;		
		this.totamount=totamount;
	}
	public Orders(String client_id, String productId, int quantity, String size, double totamount) {
		super();
		this.client_id = client_id;
		this.productId = productId;
		this.quantity = quantity;
		this.size = size;		
		this.totamount=totamount;
	}

	public int getOrder_id() {
		return order_id;
	}

	public void setOrder_id(int order_id) {
		this.order_id = order_id;
	}

	

	public String getClient_id() {
		return client_id;
	}

	public void setClient_id(String client_id) {
		this.client_id = client_id;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public Blob getImage() {
		return image;
	}

	public void setImage(Blob image) {
		this.image = image;
	}

	public double getTotamount() {
		return totamount;
	}

	public void setTotamount(double totamount) {
		this.totamount = totamount;
	}

	
	
	
	
}
