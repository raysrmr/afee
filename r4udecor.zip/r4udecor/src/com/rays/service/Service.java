package com.rays.service;

import java.util.List;

import com.rays.dao.DaoImpl;
import com.rays.model.Customer;


public class Service {

	private DaoImpl daoImpl;
	
	
	public void setUserDao(DaoImpl daoImpl) {
		this.daoImpl = daoImpl;
	}
	
	//Create of CRUD
	 public <K> int addUser(K entity) {
		 return daoImpl.addUser(entity);
		 }
	 
	//Read of CRUD	    
	    	 public boolean getCustomerById(String user,String password) {
	    	return daoImpl.getCustomerById(user,password);
	    }
	    	 
	    	 public boolean getAdminById(String user,String password) {
	 	    	return daoImpl.getAdminById(user,password);
	 	    }
	    	 
	    	 public List<Customer> getAllUsers() {
	    			return daoImpl.getAllUsers();
	    		}
	 
	 //Read of CRUD
	/*

	
	    
	  //Update of CRUD
	    public void updateUser(User user) {
	    	userDao.updateUser(user);
	    }

	    //Delete of CRUD
	    public void deleteUser(int userid) {
	    	userDao.deleteUser(userid);
	    }

		public UserDao getUserDao() {
			return userDao;
		}*/

		
}
