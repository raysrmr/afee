package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rays.dao.DaoImpl;
import com.rays.model.Product;
import com.rays.service.Service;



@WebServlet("/InsertProduct")
@MultipartConfig
public class InsertProduct extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		PrintWriter pw=response.getWriter();			
		String name=request.getParameter("product_name");
		String product_id=request.getParameter("product_id");
		String category=request.getParameter("category");		
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		String details=request.getParameter("details");				
		double price=Double.parseDouble(request.getParameter("price"));
		Product product=new Product(category, details, name, price, product_id, quantity);
		
		try {
			Service service = new Service();
			DaoImpl daoImpl = new DaoImpl();
			service.setUserDao(daoImpl);
			int status=service.addUser(product);	
			
			if(status==1) {
			pw.print("Done....");
			session.setAttribute("pok", "ok");
			request.getRequestDispatcher("products.jsp").forward(request, response);
			}else
			{
				session.setAttribute("pok", "not_ok");
				request.getRequestDispatcher("products.jsp").forward(request, response);	
			}
			
		}catch (Exception e) {
			// TODO: handle exception
			
		}
		
		
	}

}

















