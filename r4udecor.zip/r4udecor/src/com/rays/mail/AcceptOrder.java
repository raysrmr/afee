package com.rays.mail;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.rays.mail.Mailer;
import com.rays.db.DBConn;

/**
 * Servlet implementation class AcceptOrder
 */
@WebServlet("/AcceptOrder")
public class AcceptOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AcceptOrder() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		int order_id=Integer.parseInt(request.getParameter("id"));
		String mail=null;
		String una=null;
		String from="r4udecor@gmail.com";
		String password="walif@123";
		String sub="Order Accepted";
		
		try {
		Connection con=DBConn.getCon();
		PreparedStatement st=con.prepareStatement("select mail,user_name from customer where user_name=(select client_id from Orders where order_id=?)");
		st.setInt(1, order_id);
		ResultSet rs=st.executeQuery();
		while(rs.next())
		{
			mail=rs.getString(1);
			una=rs.getString(2);
		}
		
		String msg="<center><p>Hi "+una+",<p>\r\n" + 
				"<h2>Thank you for your order!</h2>\r\n" + 
				"<h3>Here's a summary of your purchase. When we ship the item, we will send an update with tracking details.</h3> </center>";
		int status=Mailer.send(from, password, mail, sub, msg);
		if(status==1)
		{
			pw.print("Mail Send");
		}else
		{
			pw.print("Mail Not Send");
		}
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in Accept Order : "+e);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
