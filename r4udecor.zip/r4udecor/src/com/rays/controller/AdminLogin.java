package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;


//import javax.mail.Session;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rays.dao.DaoImpl;

import com.rays.service.Service;


/**
 * Servlet implementation class AdminLogin
 */
@WebServlet("/AdminLogin")
public class AdminLogin extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();
		PrintWriter out=response.getWriter();
		String mail=request.getParameter("user_name");
		String pass=request.getParameter("password");
		
		
try {
			
			Service service = new Service();
			DaoImpl daoImpl = new DaoImpl();
			service.setUserDao(daoImpl);
			boolean status=service.getAdminById(mail,pass);
			if(status == true)
			{
				out.println("Status : "+status);
			session.setAttribute("allowAdmin", "allowAdmin");
			session.setAttribute("admin", mail);
			request.getRequestDispatcher("adminHome.jsp").forward(request, response);
			}else {
				
				session.setAttribute("allowAdmin", "notAdmin");
				request.getRequestDispatcher("alogin.jsp").forward(request, response);
			}
				
			
			
			
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in Customer Login : "+e);
		}
		
		/*if(mail!=null&&pass!=null) {
			try{
				Admin admin=.getAdminByMail(mail, pass);
				if(admin!=null) {
					session.setAttribute("allowAdmin", "allowAdmin");
					
					response.sendRedirect("adminHome.jsp");
					return;
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}catch (Exception e) {
				// TODO: handle exception
			}
			response.sendRedirect("alogin.jsp");
			return;
			
		}*/
	}

}
