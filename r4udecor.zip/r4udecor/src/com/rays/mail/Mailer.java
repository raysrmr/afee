package com.rays.mail;

import java.util.Properties;    
import javax.mail.*;    
import javax.mail.internet.*;

import org.romaframework.module.mail.javamail.SMTPAuthenticator;    
public class Mailer{  
    public static int send(String from,String password,String to,String sub,String msg){  
          //Get properties object    
    	int status=0;
          Properties props = new Properties();    
          props.put("mail.smtp.host", "smtp.gmail.com");    
          props.put("mail.smtp.socketFactory.port", "485");    
          props.put("mail.smtp.socketFactory.class",    
                    "javax.net.ssl.SSLSocketFactory");    
          props.put("mail.smtp.auth", "true");    
          props.put("mail.smtp.starttls.enable","true");
          props.put("mail.smtp.port", "485");    
          //get Session   
          Session session = Session.getDefaultInstance(props,    
           new javax.mail.Authenticator() {    
           protected PasswordAuthentication getPasswordAuthentication() {    
           return new PasswordAuthentication(from,password);  
           }    
          });    
          //compose message    
          try {    
           MimeMessage message = new MimeMessage(session);    
           message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));    
           message.setSubject(sub);    
           message.setText(msg);    
           //send message  
           Transport.send(message);    
           System.out.println("message sent successfully");    
           return 1;
          } catch (MessagingException e) 
          {       	  
        	  //throw new RuntimeException(e);
        	  System.out.println(e);
        	  return 0;
        	  }    
             
    }  
    /*public static void mailSender(String d_email,String d_password,String m_to,String m_subject,String m_text)
    {
    //	String  d_email = "address@gmail.com",
               String d_uname = "Name";
      //          d_password = "urpassword",
               String d_host = "smtp.gmail.com";
                String d_port  = "465";
        //        m_to = "toAddress@gmail.com",
          //      m_subject = "Indoors Readable File: " + params[0].getName(),
            //    m_text = "This message is from Indoor Positioning App. Required file(s) are attached.";
        Properties props = new Properties();
        props.put("mail.smtp.user", d_email);
        props.put("mail.smtp.host", d_host);
        props.put("mail.smtp.port", d_port);
        props.put("mail.smtp.starttls.enable","true");
        props.put("mail.smtp.debug", "true");
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.socketFactory.port", d_port);
        props.put("mail.smtp.socketFactory.class", "javax.net.ssl.SSLSocketFactory");
        props.put("mail.smtp.socketFactory.fallback", "false");

        SMTPAuthenticator auth = new SMTPAuthenticator(userid, passwd);
        Session session = Session.getInstance(props, auth);
        session.setDebug(true);

        MimeMessage msg = new MimeMessage(session);
        try {
            msg.setSubject(m_subject);
            msg.setFrom(new InternetAddress(d_email));
            msg.addRecipient(Message.RecipientType.TO, new InternetAddress(m_to));

    Transport transport = session.getTransport("smtps");
                transport.connect(d_host, Integer.valueOf(d_port), d_uname, d_password);
                transport.sendMessage(msg, msg.getAllRecipients());
                transport.close();

        } catch (AddressException e) {
            e.printStackTrace();
           // return false;
        } catch (MessagingException e) {
            e.printStackTrace();
            //return false;
        }
    }*/
}  
  