package com.rays.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.rays.dao.DaoImpl;
import com.rays.model.Customer;
//import com.dealhere.entity.Client;
import com.rays.service.Service;


@WebServlet("/LoginClient")
public class LoginClient extends HttpServlet {

	private static final long serialVersionUID = 1L;

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		
		PrintWriter out=resp.getWriter();
		HttpSession session=req.getSession();
		String user=req.getParameter("user_name");
		String pass=req.getParameter("password");
		
		try {
			
			Service service = new Service();
			DaoImpl daoImpl = new DaoImpl();
			service.setUserDao(daoImpl);
			boolean status=service.getCustomerById(user,pass);
			if(status == true)
			{
				out.println("Status : "+status);
			session.setAttribute("isValid", "valid");
			session.setAttribute("customer", user);
			req.getRequestDispatcher("index.jsp").forward(req, resp);
			}else {
				
				session.setAttribute("isValid", "invalid");
				req.getRequestDispatcher("login.jsp").forward(req, resp);
			}
				
			
			
			
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in Customer Login : "+e);
		}
		
	}
	
	
	
}
