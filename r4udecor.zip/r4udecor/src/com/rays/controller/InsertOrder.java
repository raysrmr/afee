package com.rays.controller;


import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Blob;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import org.hibernate.Hibernate;
import org.hibernate.Session;

import com.rays.dao.DaoImpl;
import com.rays.model.Orders;
import com.rays.service.Service;
import com.rays.util.HibernateUtil;




@WebServlet("/InsertOrder")
@MultipartConfig
public class InsertOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
		
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession();	
		PrintWriter pw=response.getWriter();
		String productId=request.getParameter("product_id");		
		int quantity=Integer.parseInt(request.getParameter("quantity"));
		String size=request.getParameter("size");
		String client_id=(String)session.getAttribute("customer");
		Part filePart = request.getPart("image");	
				
		
		//File f=new File(request.getParameter("image"));
		int price=Integer.parseInt(request.getParameter("price"));
		System.out.println("Price : "+price);
		InputStream inputStream = filePart.getInputStream();		
		
		double totamount = quantity*price;
		
		Session session1 = HibernateUtil.getSessionFactory().openSession();
		
		Orders orders=new Orders(client_id, productId, quantity, size,  totamount);
		
		Blob blob = (Blob) Hibernate.getLobCreator(session1).createBlob(inputStream, filePart.getSize());		
				orders.setImage(blob);
				
		
		
		try {
			
			Service service = new Service();
			DaoImpl daoImpl = new DaoImpl();
			service.setUserDao(daoImpl);
			service.addUser(orders);	
			
			blob.free();
			
			pw.println("Order Taken");
			
			List<Orders> or=daoImpl.getOrderIdByUser(client_id);
		
			Orders order=null;
			for(Orders ord:or)
			{
				order=new Orders(ord.getOrder_id(), ord.getClient_id(), ord.getProductId(), ord.getQuantity(), ord.getSize(), ord.getTotamount());
			}
			/*List<Orders> li=new ArrayList<>();
			//li.add(or);
			pw.println("OrderID : "+or.getOrder_id());
			pw.println("OrderID : "+or.getClient_id());
			pw.println("OrderID : "+or.getProductId());*/
			
			
			request.setAttribute("orders", order);
			request.getRequestDispatcher("orderTaken.jsp").forward(request, response);
			
			/*int order_id=0;
			Statement st=connection.createStatement();
			ResultSet rss=st.executeQuery("select order_id from Orders");
			while(rss.next())
			{
				order_id=rss.getInt("order_id");
			}
			
			Orders order=new Orders(order_id, client_id, productId, quantity, size, totamount);
			List<Orders> li=new ArrayList<>();
			li.add(order);
			request.setAttribute("orders", order);
			request.getRequestDispatcher("orderTaken.jsp").forward(request, response);*/
			
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	

}

















