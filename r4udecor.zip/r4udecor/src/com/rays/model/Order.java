package com.rays.model;


public class Order {
	
	private int id;		
	private String productId;
	private String quantity;
	private String size;
	private String img_of_wall;
	
	public Order() {
		
	}

	public Order(String productId, String quantity, String size, String img_of_wall) {
		super();
		this.productId = productId;
		this.quantity = quantity;
		this.size = size;
		this.img_of_wall = img_of_wall;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductId() {
		return productId;
	}

	public void setProductId(String productId) {
		this.productId = productId;
	}

	public String getQuantity() {
		return quantity;
	}

	public void setQuantity(String quantity) {
		this.quantity = quantity;
	}

	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}

	public String getImg_of_wall() {
		return img_of_wall;
	}

	public void setImg_of_wall(String img_of_wall) {
		this.img_of_wall = img_of_wall;
	}

	@Override
	public String toString() {
		return "Order [id=" + id + ", productId=" + productId + ", quantity=" + quantity + ", size=" + size
				+ ", img_of_wall=" + img_of_wall + "]";
	}
	
	
	
	
}
