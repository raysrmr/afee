package com.rays.controller;

import java.io.IOException;
import java.io.OutputStream;
import java.sql.Blob;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.Date;
import com.rays.db.DBConn;



/**
 * Servlet implementation class GetImage
 */
@WebServlet("/GetImage")
public class GetImage extends HttpServlet {
	private static final long serialVersionUID = 1L;
	//private static int i;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GetImage() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		byte[] imaData=null;
		try {
								
				Connection con=DBConn.getCon();				
				int id= Integer.parseInt(request.getParameter("id"));
				System.out.println("Order ID : "+id);
				PreparedStatement st=con.prepareStatement("select image from orders where order_id=?");
				st.setInt(1, id);
				ResultSet rs=st.executeQuery();
				while(rs.next())
				{
            	Blob image =(Blob)rs.getBlob(1);
            	imaData = image.getBytes(1, (int) image.length());
				}            	            	
            	OutputStream output = response.getOutputStream();
            	response.setContentType("image/gif");
            	output.write(imaData);
            	output.flush();
            	output.close();
            	           	
            	
            	
           
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in Image:"+new Date()+"\t"+e); 
			//request.setAttribute("noimg", "noimg");
			
		}
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
