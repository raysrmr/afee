package com.rays.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.Query;
//import javax.persistence.Query;

import com.rays.model.Admin;
import com.rays.model.Customer;
import com.rays.model.Orders;
import com.rays.util.HibernateUtil;

public class DaoImpl {
	
	//Create of CRUD
	 public <K> int addUser(K entity) {
	        Transaction trns = null;
	        
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        try {
	            trns = session.beginTransaction();
	            session.save(entity);
	            session.getTransaction().commit();
	            return 1;
	        } catch (RuntimeException e) {
	            if (trns != null) {
	                trns.rollback();
	            }	            
	            e.printStackTrace();
	            return 0;
	        } finally {
	            session.close();
	        }
	    }
	 
	//Read of CRUD
	    //public List<User> getUserById(int userid) {
	public boolean getCustomerById(String user,String password) {
	    	List<Customer> customer = new ArrayList<Customer>();
	    	boolean status =false;
	    	int count = 0;
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        try {
	        	String SQL_QUERY =" from Customer as o where o.user_name=? and o.password=?";
				Query query = session.createQuery(SQL_QUERY);
				query.setParameter(0,user);
				query.setParameter(1,password);
				List list = query.list();

				if ((list != null) && (list.size() > 0)) {
					status= true;
				}
	            } catch (RuntimeException e) {
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	        return status;
	    }
	
	
	public boolean getAdminById(String mail,String password) {
    	List<Admin> admin = new ArrayList<Admin>();
    	boolean status =false;
    	int count = 0;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
        	String SQL_QUERY =" from Admin as o where o.mail=? and o.password=?";
			Query query = session.createQuery(SQL_QUERY);
			query.setParameter(0,mail);
			query.setParameter(1,password);
			List list = query.list();

			if ((list != null) && (list.size() > 0)) {
				status= true;
			}
            } catch (RuntimeException e) {
            e.printStackTrace();
        } finally {
            session.close();
        }
        return status;
    }
	
	//Read of CRUD
    //public List<User> getUserById(int userid) {
public List getOrderIdByUser(String user) {
    	List<Orders> cust = new ArrayList<Orders>();
    	Orders or=null;
        Session session = HibernateUtil.getSessionFactory().openSession();
        try {
            String hqlQuery = "from Orders where client_id = :id";
           @SuppressWarnings("rawtypes")
			Query query = session.createQuery(hqlQuery);
            query.setParameter("id", user);        	
        	 //or = (Orders)session.get(Orders.class, user);
            cust =  query.list();
           
            } catch (RuntimeException e) {
            e.printStackTrace();
            System.out.println("Error in getorder : "+e);
        } finally {
            session.close();
        }
        return cust;
    }
	 
	 //Read of CRUD
	@SuppressWarnings("unchecked")
	public List<Customer> getAllUsers() {
	        List<Customer> users = new ArrayList<Customer>();
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        try {
	        	//Query qry=session.createQuery("");
	            users = session.createQuery("from Customer").list();
	        } catch (RuntimeException e) {
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	        return users;
	    }

	
	    
	/*  //Update of CRUD
	    public void updateUser(User user) {
	        Transaction trns = null;
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        try {
	            trns = session.beginTransaction();
	            session.update(user);
	            session.getTransaction().commit();
	        } catch (RuntimeException e) {
	            if (trns != null) {
	                trns.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    }

	    //Delete of CRUD
	    public void deleteUser(int userid) {
	        Transaction trns = null;
	        Session session = HibernateUtil.getSessionFactory().openSession();
	        try {
	            trns = session.beginTransaction();
	            User user = (User) session.load(User.class, new Integer(userid));
	            session.delete(user);
	            session.getTransaction().commit();
	        } catch (RuntimeException e) {
	            if (trns != null) {
	                trns.rollback();
	            }
	            e.printStackTrace();
	        } finally {
	            session.close();
	        }
	    }*/

	    
}
