package com.rays.model;



public class Product {
		
	private String product_id;		
	private String category;		
	private String details;
	private String name;
	private double price;		
	private int quantity;
	
	public Product() {
		
	}

	public Product(String category, String details, String name, double price, String product_id, int quantity) {
		super();
		this.category = category;
		this.details = details;
		this.name = name;
		this.price = price;
		this.product_id = product_id;
		this.quantity = quantity;
	}
	
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

	public String getDetails() {
		return details;
	}

	public void setDetails(String details) {
		this.details = details;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getProduct_id() {
		return product_id;
	}

	public void setProduct_id(String product_id) {
		this.product_id = product_id;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
}
