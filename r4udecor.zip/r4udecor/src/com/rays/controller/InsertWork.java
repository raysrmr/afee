package com.rays.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.rays.db.DBConn;



/**
 * Servlet implementation class InsertWork
 */
@WebServlet("/InsertWork")
@MultipartConfig
public class InsertWork extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public InsertWork() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		try {
			
			Part filePart_img = request.getPart("upimg");
			Part filePart_vid = request.getPart("upvid");	
			String category = request.getParameter("category");			
			
			InputStream inputStream_img = filePart_img.getInputStream();			
			InputStream inputStream_vid = filePart_vid.getInputStream();
			
			ServletContext sc=getServletContext();
			Connection con=DBConn.getCon();
			PreparedStatement ps=con.prepareStatement("INSERT INTO work_history(category,image,video)VALUES(?,?,?)");
			
			ps.setString(1, category);			
			ps.setBlob(2, inputStream_img);
			ps.setBlob(3, inputStream_vid);
			
			
			ps.execute();
			pw.println("Done");
			request.getRequestDispatcher("work.jsp").forward(request, response);
		}catch (Exception e) {
			// TODO: handle exception
			System.out.println("Error in Upload Image : "+e);
		}
	}

}
